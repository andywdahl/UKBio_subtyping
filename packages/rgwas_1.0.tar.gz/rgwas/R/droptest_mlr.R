droptest_mlr	<- function(
	cc, Yb, Y, G, X=NULL, test_inds, K,
	tau=.8,
	mc.cores=1,
	pmat=NULL,
	tolfac=1e-4, MaxNWts=1e5, scaleXg=TRUE,
	...
){

	if( 2*length(test_inds) > mc.cores ){
		mc.cores1	<- mc.cores
		mc.cores2	<- 1
	} else {
		mc.cores1	<- length(test_inds)
		mc.cores2	<- floor( mc.cores / mc.cores1 )
	}

	cases	<- which( cc == 1 )
	Yb	<- Yb[cases,,drop=F]
	Yq	<- scale(Yq[cases,,drop=F])
	
	out	<- parallel::mclapply( 1:ncol(G), mc.cores=mc.cores1, function(test_ind){
		if( ! test_ind %in% test_inds ) return( list() )
		cat( 'Running G index ', test_ind, '\n' )

	#tryCatch({
		g	<- G[, test_ind,drop=F]
		G	<- G[,-test_ind,drop=F]

		if( is.null(pmat) ){
			cat( 'hetreg_time:', hetreg_time	<- system.time({
				all_out	<- mfmr(Yb, Yq, G[cases,,drop=F], cbind( X, g )[cases,,drop=F], K, mc.cores=mc.cores2, ... )
			})[3], '\n' )
			pmat	<- fit_z(		Yb, Yq, G[cases,,drop=F], cbind( X, g )[cases,,drop=F], all_out$out )
		}
		Z					<- rep( '0', length(cc) )
		Z[cases]	<- as.character(apply( pmat, 1, function(x) ifelse( max(x) > tau, which.max(x), NA ) ))
	#}, error=function(e) print(e) , error=function(e) print( paste0( 'ERROR: ', e ) ) )


		#### todo: add ordinary droptest here
		run_mlr( cbind( G, X ), g, Z, tolfac=tolfac, MaxNWts=MaxNWts, scaleXg=scaleXg )
	})
	names(out)	<- colnames(G)
	out
}

scale01	<- function(x){
	x	<- x - min(x,na.rm=T)
	x	<- x / max(x,na.rm=T)
	x
}

run_mlr	<- function( X, g, z, tolfac=1e-4, MaxNWts=1e5, scaleXg=TRUE ){

	if( any( is.na( z ) ) ){
		K			<- length(unique(z))-2
	} else {
		K			<- length(unique(z))-1
	}

	count_tab	<- as.numeric( table( rep( 1:4, each=2 ) ) )
	cat( 'Found ', count_tab[1], ' controls; and case subtypes have sizes: ', count_tab[-1], '\n' )

	if( ! all( X[,1] == 1 ) ) stop( 'The first column of X should be an intercept, or a vector of all 1s' )
	if( scaleXg ){
		X	<- cbind( 1, apply( X[,-1], 2, scale01 ) )
		g	<- scale01(g)
	}

	suppressMessages( out		<- nnet::multinom( z ~ -1+X+g, Hess=T, maxit=1e3, abstol = 1.0e-4*tolfac, reltol = 1.0e-8*tolfac, MaxNWts=MaxNWts  ) )

	betas			<- as.numeric( summary(out)$coefficients		[,ncol(X)+1] )
	betas.se	<- as.numeric( summary(out)$standard.errors	[,ncol(X)+1] )

	g_inds		<- (ncol(X)+1)*(1:K)
	tryCatch({
	var_beta	<- solve(out$Hessian)[g_inds,g_inds]
	}, error=function(e){
		#print( eigen( out$Hessian ) )
	})
	hess_beta	<- out$Hessian[g_inds,g_inds]
	rm( out )

	# contrast matrix
	T_hom	<- rep(1,K)
	T_het	<- cbind( rep(1,K-1), -diag(K-1) )
	T_glob<- diag(K)

	# beta contrast vector
	Tbeta_hom	<- T_hom %*% betas
	Tbeta_het	<- T_het %*% betas
	Tbeta_glob<- T_glob%*% betas

	# beta contrast hessian
	I_Tbeta_hom	<- T_hom %*%(var_beta %*% T_hom)
	I_Tbeta_het	<- T_het %*% var_beta %*% t(T_het)
	I_Tbeta_glob<- T_glob%*% var_beta %*% t(T_glob)

	chi2_hom	<- Tbeta_hom^2 / I_Tbeta_hom
	chi2_het	<- t(Tbeta_het) %*% solve( I_Tbeta_het ) %*% Tbeta_het
	chi2_glob	<- t(Tbeta_glob)%*% solve( I_Tbeta_glob) %*% Tbeta_glob

	#### I_Tbeta_hom	<- T_hom %*%(solve(hess_beta) %*%   T_hom)
	#### I_Tbeta_het	<- T_het %*% solve(hess_beta) %*% t(T_het)
	#### I_Tbeta_glob<- T_glob%*% solve(hess_beta) %*% t(T_glob)

	return( list( betas=betas, betas.se=betas.se, var_beta=var_beta,
		log10p_hom =-pchisq( chi2_hom	,   1	, lower.tail=F, log.p=T ) / log(10),
		log10p_het =-pchisq( chi2_het	, K-1	, lower.tail=F, log.p=T ) / log(10),
		log10p_glob=-pchisq( chi2_glob, K		, lower.tail=F, log.p=T ) / log(10)
	))
}
