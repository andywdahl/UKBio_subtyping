GxEMM	<- function(
	y, X=NULL, K, Z=NULL, ldak_loc='~/ldak5.linux ', 
	gtype=c('hom','iid','free')[1], etype=c('hom','iid','free')[1],
	binary=FALSE, prev,
	lowmem=FALSE, keep_ldak=FALSE, tmpdir=paste0( 'gxemm_tmp_', round(runif(1)*1e5) )
){
	Z		<- as.matrix(Z)
	X		<- as.matrix(X)
	K0	<- ncol(Z)

	discZ		<- all(Z %in% 0:1) & all(rowSums(Z)==1) #### sklightly better: all( svd( cbind( 1, Z^2 ) )$d > 1e-5 ) #if( length(unique(Z[,1])) == 2 )
	noise_K0<- ( binary | !discZ )

	if( discZ & etype=='iid' ){
		warning( 'IID etype not identified for discrete Z; making hom' )
		etype <- 'hom'
	}

	#### check not already ran
	if( file.exists( paste0( tmpdir, '/y.phen' ) ) ) stop('Output file already exists')

	#### set up LDAK output
	system( paste0( 'mkdir ', tmpdir ) )
	if(keep_ldak){
		outdir=paste0( 'gxemm_out_', round( abs(rnorm(1) + X[sample(10,1)] + y[sample(10,1)] )*1e5, 0 ) )
		system( paste0( 'mkdir ', outdir ) )
	} else {
		outdir=tmpdir
	}

	### write pheno + covars
	if( binary ){
		stopifnot( all( is.na(y) | (y%in%1:2) ) )
		if( missing( prev ) ){
			warning( 'Prevalence missing. Assuming binary trait isn\'t ascertained, which fails badly for rare disease case/control data' )
			prev	<- sum(y==2)/sum(y%in%1:2)
		}
	} else {
		y	<- scale(y)
	}
	write_pheno( y, file=paste0( tmpdir, '/y.phen')	 )
	write_pheno( X, file=paste0( tmpdir, '/X.qcovar') )
	X			<- cbind( 1, X )

	X_singvals	<- svd(X)$d
	if( max(X_singvals)/min(X_singvals) > 1e4 )
		stop( 'cbind(1,X) is nearly collinear; either X should be scaled or a column should be dropped' )

	### write each of the kinship matrices
	ws	<- write_kin( tmpdir, K, index=1, ldak_loc, X ) # hom K
	if( gtype == 'iid' ){
		ws	<- c( ws, write_kin( tmpdir, K * (Z %*% t(Z)), index=2, ldak_loc, X ) ) # iid K
	} else if( gtype == 'free' ){
		for( k in 1:K0 )
			ws	<- c( ws, write_kin( tmpdir, K * ( Z[,k,drop=F] %*% t(Z[,k,drop=F])	), index=1+k, ldak_loc, X ) ) # K * (Zk Zk^T)
	}
	rm(K); gc()
	if( etype == 'iid' ){
		ws	<- c( ws, write_kin( tmpdir, diag( rowSums(Z^2) ), index=length(ws)+1, ldak_loc, X ) )
	} else if( etype == 'free' ){
		for( k in 1:ifelse( noise_K0, K0, K0-1 ) )
			ws	<- c( ws, write_kin( tmpdir, diag( Z[,k]^2 ), index=length(ws)+1, ldak_loc, X ) ) # I * (Zk Zk^T)
	}
	rm(Z); gc()
	r		<- length(ws)
	ws	<- c( ws, 1 - ncol(X)/nrow(X) )
	write.table( paste0( tmpdir, '/grm.', 1:r ), file=paste0( tmpdir, '/multi_grm.txt' ), sep='\t', row.names=F, col.names=F, quote=F )
	#write.table( paste0( tmpdir, '/grm.adjusted.', 1:r ), file=paste0( tmpdir, '/multi_grm.txt' ), sep='\t', row.names=F, col.names=F, quote=F )
		try( stop( '0000000' ) )
		print( '0000000' ) 
		print( list.files(tmpdir) )

	### adjust kinships for the covariates
	for( i in 1:r ){
		write_pheno( y, file=paste0( tmpdir, '/grm.', i, '.grm.details')	 )
		write_pheno( y, file=paste0( tmpdir, '/grm.', i, '.grm.adjust')	 )
		adjust_ldak_kinship( prefix=paste0( tmpdir, '/grm.', i ), ldak_loc, covarfile=paste0( tmpdir, '/X.qcovar ' ) )
		#adjust_ldak_kinship( prefix=paste0( tmpdir, '/grm.adjusted.', i ), grm=paste0( tmpdir, '/grm.', i ), ldak_loc, covarfile=paste0( tmpdir, '/X.qcovar ' ) )
	}

		print( list.files(tmpdir) )
		print( list.files('kins/') ) 
		print( '1111111' )
		try( stop( '1111111' ) )

	failed	<- TRUE
	try({
		# R -> LDAK
		system( paste0( ldak_loc,
			ifelse( r==1, 
				#paste0(	' --grm ', tmpdir, '/grm.adjusted.1 '  ),
				#paste0( ' --mgrm ', tmpdir, '/multi_grm.txt ' )
				paste0(	' --grm ', tmpdir, '/grm.1 '  ),
				paste0( ' --mgrm ', tmpdir, '/multi_grm.txt ' )
			), 
			' --pheno ', tmpdir, '/y.phen ',
			' --covar ', tmpdir, '/X.qcovar ',
			ifelse( binary, ' --pcgc ', ' --reml ' ), outdir, '/tmp',
			ifelse( binary, paste0( ' --prevalence ', prev ), '' ),
			' --memory-save ', ifelse( lowmem , 'YES ', 'NO ' ),
			' --kinship-details NO'
		))
		# LDAK -> R
		gout	<- extract_ldak( binary, outdir, ws, r )
		failed	<- FALSE
	}) 
		print( '2222222' )
		try( stop( '2222222' ) ) 

	system( paste0( 'rm -rf ', tmpdir ) )
	if( failed ) return('FAILED')

	# convert to more meaningful parameters
	sig2out		<- sig2map( gout$sig2s, gtype, etype, K0, noise_K0, discZ, ws )
	h2Covmat	<- msm::deltamethod( sig2out$form, gout$sig2s, gout$sig2Var, ses=F )

	list( h2=sig2out$h2, sig2g=sig2out$sig2g, sig2e=sig2out$sig2e, df=r, sig2s=gout$sig2s, ll=gout$ll, h2Covmat=h2Covmat, sig2Var=gout$sig2Var, betas=gout$betas, ws=ws )
}
