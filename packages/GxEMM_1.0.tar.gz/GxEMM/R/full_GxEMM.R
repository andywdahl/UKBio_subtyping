full_GxEMM	<- function(y, X, K, Z, binary, ldak_loc, 
	hom=TRUE, hom_IID=TRUE, hom_free=TRUE, IID=TRUE, free=TRUE, ... ){

	runtimes	<- list( hom=NA	, hom_iid=NA, hom_free=NA, iid=NA, free=NA )
	fits			<- list( hom=NA	, hom_iid=NA, hom_free=NA, iid=NA, free=NA  )

	if( hom ){
	print( 'Running Hom' )
	runtimes$time_hom      <- system.time( fits$hom       <- GxEMM( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='hom'									, ... ) )[3]
	gc()
	}

	if( hom_IID ){
	print( 'Running Hom_IID' )
	runtimes$time_hom_iid  <- system.time( fits$hom_iid   <- GxEMM( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='hom'  , etype='iid' 	, ... ) )[3]
	gc()
	}

	if( hom_free ){
	print( 'Running Hom_Free' )
	runtimes$time_hom_free <- system.time( fits$hom_free  <- GxEMM( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='hom'  , etype='free'	, ... ) )[3]
	gc()
	}

	if( IID ){
	print( 'Running IID' )
	runtimes$time_iid      <- system.time( fits$iid       <- GxEMM( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='iid'  , etype='iid'	, ... ) )[3]
	gc()
	}

	if( free ){
	print( 'Running Free' )
	runtimes$time_free     <- system.time( fits$free      <- GxEMM( y, X, K, Z, binary=binary, ldak_loc=ldak_loc, gtype='free' , etype='free'	, ... ) )[3]
	gc()
	} 

	list( 
		runtimes=runtimes,
		fits=fits,
		pvals=test_gxemm( fits$hom, fits$iid, fits$hom_iid,  fits$free, fits$hom_free )
	)

}
