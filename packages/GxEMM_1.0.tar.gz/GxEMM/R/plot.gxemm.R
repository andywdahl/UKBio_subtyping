plot.gxemm	<- function(
	h2greml, h2iid, h2free,
	se.h2greml, se.h2iid, se.h2iidsum, se.h2free,
	p.h2greml, p.h2hom, p.h2het, p.h2iid, p.h2free,
	pdfname,
	xlab=c( 'GREML', 'Hom', 'IID', 'Hom+IID', 'Free 1', 'Free 2' ),
	cols=c( 'grey', 1, '#FFBB00', 'brown', '#FB6542', '#3F681C', '#375E97' )
){

	if( !missing(pdfname) )
		pdf( pdfname, width=6, height=5 )
	par( mar=c(8,6,.5,.5) )

	plot( c( 1, 3.2 ), c(-.3,1.02), type='n', axes=F, xlab='', ylab='Variance Explained', bty='n', cex.lab=1.6 )
	axis(2,cex.axis=.75,at=c(-(1:2)/4,0:4/4),lab=paste0( c( -(1:2)/4, 0:4/4 )*100, '%' ),tick=F)
	abline( h=0, lty=1, col=1, lwd=1.5 )
	abline( h=1, lty=1, col=1, lwd=1.5 )
	for( x in c( -(1:2)/4, 1:3/4 ) )
	abline( h=x, lty=3, col='lightgrey', lwd=1.5 )

	xvals	<- c( 1.05, 1.6, 1.9, 2.2, 2.8, 3.1 )
	mylines( xvals[1], h2greml		, se.h2greml	,trunc=F, col=cols[1], points=T,pt.cex=3, asts=sum( p.h2greml < c( 1e-3,1e-2,.05) ) )
	mylines( xvals[2], h2iid[1]		, se.h2iid[1]	,trunc=F, col=cols[2], points=T,pt.cex=3, asts=sum( p.h2hom		< c( 1e-3,1e-2,.05) ) )
	mylines( xvals[3], h2iid[2]		, se.h2iid[2]	,trunc=F, col=cols[3], points=T,pt.cex=3, asts=sum( p.h2het		< c( 1e-3,1e-2,.05) ) )
	mylines( xvals[4], sum(h2iid)	, se.h2iidsum	,trunc=F, col=cols[4], points=T,pt.cex=3, asts=sum( p.h2iid		< c( 1e-3,1e-2,.05) ) )
	mylines( xvals[5], h2free[1]	, se.h2free[1],trunc=F, col=cols[5], points=T,pt.cex=3 )
	mylines( xvals[6], h2free[2]	, se.h2free[2],trunc=F, col=cols[6], points=T,pt.cex=3 )


	axis( 1, at=xvals, lab=xlab, las=2, tick=F, cex.axis=1.6 )

	if( !missing(pdfname) )
		dev.off()

}
