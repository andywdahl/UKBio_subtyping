test_gxemm	<- function( out_hom, out_iid, out_iid_homG, out_free, out_free_homG ){ # , out_homE

	hom	<- hom_lr	<- hom_freeE<- hom_freeE_lr	<- NA
	iid	<- iid_lr	<- iid1			<- iid1_lr			<- NA
	free<- free_lr<- free1		<- free1_lr			<- NA
	h2eq<- NA

	if( !missing(out_hom) )try({
		hom			<- Waldtest( out_hom$h2, out_hom$h2Covmat[1,1] )
	})

	if( !missing(out_free_homG) )try({
	hom_freeE		<- Waldtest( out_free_homG$sig2s[1], out_free_homG$sig2Var[1,1] )
	})

	if( !missing(out_iid) )try({
		iid		<- Waldtest(	out_iid$sig2s[2]	, out_iid$sig2Var[2,2] )
		iid1	<- MVWaldtest(out_iid$sig2s[2:3], out_iid$sig2Var[2:3,2:3] )
	})

	if( !missing(out_hom) & !missing(out_iid) ) try({
		iid1_lr	<- LRtest( ll1=out_iid$ll, ll0=out_hom$ll, df=out_iid$df-out_hom$df )
	})

	print( 'bbbbbbbb' )
	print( out_iid_homG )
	print( out_iid_homG[1] )

	if( !missing(out_iid_homG) & !missing(out_iid) )try({
		iid_lr	<- ifelse( out_iid_homG$df == out_hom$df, iid1_lr,
		LRtest( ll1=out_iid$ll, ll0=out_iid_homG$ll, df=out_iid$df-out_iid_homG$df )
		)
	})

	print( 'cccccccc' )
	print( out_free )
	print( out_free[1] )

	if( !missing(out_free) ) try({
	K0				<- length( out_free$h2 )
	if( K0 > 1 ){
	h2eq		<- h2_equal_test( out_free$h2, out_free$h2Covmat )
	free		<- MVWaldtest( out_free$sig2s[1+1:K0], out_free$sig2Var[1+1:K0,1+1:K0] )
	### need to figure out how sig2e is parameterized here first: free1		<- MVWaldtest( out_free$sig2s[1+1:(2*K0)], out_free$sig2Var[1+1:K0,1+1:K0] )
	free1_lr<- LRtest( ll1=out_free$ll, ll0=out_hom$ll, df=out_free$df-out_hom$df )
	}})

	if( !missing(out_free_homG) & !missing(out_free) )try({
		if( K0 > 1 )
			free_lr<- LRtest( ll1=out_free$ll, ll0=out_free_homG$ll, df=out_free$df-out_free_homG$df )
	})

	out				<- c( hom	, hom_lr	, iid	, iid_lr	, iid1	, iid1_lr		, free	, free_lr	, free1	, free1_lr	, h2eq	, hom_freeE		, hom_freeE_lr )
	names(out)<- c( 'hom','hom_lr','iid','iid_lr'	, 'iid1', 'iid1_lr'	, 'free','free_lr','free1','free1_lr'	,'h2eq'	, 'hom_freeE'	,'hom_freeE_lr')
	out
}

h2_equal_test	<- function( h2s, h2Covmat ){#, prevs_sam, prevs_pop=prevs_sam ){
	K0			<- length( h2s )
	if( K0 == 1 ) return(NA)
	Tmat		<- cbind( 1, -diag(K0-1) )
	Tmath2	<- Tmat %*% as.numeric(h2s)
	chi2val	<- as.numeric( solve( Tmat %*% h2Covmat %*% t(Tmat) ) %*% Tmath2 ) %*% Tmath2 
	as.numeric( pchisq( chi2val, df=K0-1, lower.tail=F ) )
}

LRtest	<- function( ll1, ll0, df )
	pchisq( 2*(ll1-ll0), df=df, lower.tail=F )

Waldtest	<- function( z, Var )
	as.numeric(pnorm( z/sqrt(Var), lower.tail=F ))

MVWaldtest	<- function( z, Var, eigtol=1e8 ){
	Var		<- 1/2*(Var+t(Var))
	eval	<- eigen(Var,symmetric=TRUE)$values
	if( max(eval)/(min(eval)+1e-99) > eigtol | min(eval)<0 )
		return(NA)
	as.numeric(pchisq( as.numeric(z) %*% (solve(Var) %*% as.numeric(z)), df=length(z), lower.tail=F ))
}
